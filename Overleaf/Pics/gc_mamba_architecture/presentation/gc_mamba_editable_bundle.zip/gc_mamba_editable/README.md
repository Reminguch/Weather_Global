# Editable architecture figures

Open these files in desktop PowerPoint or Keynote:

- `02_correction_branch.pptx`: one slide, matching the original figure's 16 × 3.4 inch canvas.
- `03_temporal_rollout.pptx`: one slide, matching the original figure's 16 × 6.9 inch canvas.
- `gc_mamba_editable_figures.pptx`: both figures on separate 16:9 slides.

## Editing

1. Install the four DejaVu Sans fonts from `fonts/` before opening the presentation
   to keep the original label metrics. On macOS, open the font files with Font
   Book and install them. Their redistribution license is included.
2. In Keynote, use File → Open and select the `.pptx`; save as a Keynote file if
   desired. In PowerPoint, open the `.pptx` directly.
3. Boxes, arrow paths, and labels are native objects. Select a group and use
   Ungroup when needed to edit its components. Mathematical labels use small
   grouped text boxes for subscripts and superscripts, rather than an equation
   editor. Shape outlines and labels are separate objects; select and group
   them together before moving a labeled box.
4. Arrowheads and shafts are grouped. Paths can be resized or edited, but are
   not attached connectors: moving a box requires adjusting its arrows.
5. The Earth illustrations and mesh overlays are separate movable, replaceable
   PNG pictures with circular crops. Their pixels are not editable vector shapes.

For LaTeX, edit the figure-sized single-slide deck and export it as PDF. Save
the edited `.pptx` or `.key` as the new editable source. The Python SVG generator
does not read edits made in presentation software.

## Verification and reproduction

The original SVG/PDF/PNG files were left unchanged. Shapes, label positions,
colors, and image layers were converted from the SVGs. Source SHA-256 hashes and
counts of editable objects appear in `export-report.json`.

The generated presentations were reopened and all nested objects checked with
python-pptx. A reconstruction from the serialized presentation geometry was
rendered for visual inspection. Native PowerPoint and Keynote were unavailable
on this Linux host, so their import/font rendering has not been directly tested.

Recreate the decks from the repository root:

```bash
python -m pip install --target .cache/presentation-python python-pptx==1.0.2 Pillow
PYTHONPATH=.cache/presentation-python python scripts/export_gc_mamba_pptx.py
```

The exporter uses the system DejaVu Sans fonts and their license under
`/usr/share/fonts/dejavu-sans-fonts` and `/usr/share/licenses/dejavu-sans-fonts`.

References:
- [Apple: open and edit PowerPoint presentations in Keynote](https://support.apple.com/guide/keynote/tan72232b56/mac)
- [Microsoft: SVG editing and conversion to shapes](https://support.microsoft.com/en-us/office/graphics-visuals/edit-svg-images-in-microsoft-365)
