from pathlib import Path
import json,csv,hashlib,textwrap,shutil,zipfile,subprocess
from datetime import datetime
from zoneinfo import ZoneInfo
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
R=Path('/scratch/gpfs/DABANIN/iv9432/Weather_global'); name='v24_amse_summary_20261007'
D=R/'plots/analyze_models/data/resolution_eval'/name; I=R/'plots/analyze_models/images/resolution_eval'/name
D.mkdir(parents=True,exist_ok=True); I.mkdir(parents=True,exist_ok=True)
OUT=R/'docs/reports'; C=R/'artifacts/checkpoints/v24_Ilya/res1_amse_joint_regime_20261004'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
sources=[]
def read(p):
 p=Path(p); sources.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});return json.loads(p.read_text())
phases={p:read(C/p/'evaluation/report/joint_selection.json') for p in ['trajectory','pilot','feedback','adaptive']}
old={label:read(R/'plots/analyze_models/data/resolution_eval'/folder/'comparison.json') for label,folder in [('Full AMSE','res1_amse_pair_20260919'),('AMSE λ=0.1','res1_amse_blend_lambda0p1_20260924')]}
status=read(C/'status.json'); plan=read(C/'confirmation/plan.json'); dates=read(C/'confirmation/evaluation/initializations.json')
for d in phases.values():
 assert d['status']=='complete' and not d['missing']
 for r in d['records']:
  assert len(r['score']['per_feature_lead'])==36
assert all(Path(e['stages'][-1]['checkpoint']).exists() for e in plan['entries'])
rows=[]
for p,d in phases.items():
 for r in d['records']:
  s=r['score'];rows.append(dict(phase=p,id=r['id'],family=r['family'],step=r.get('step'),gc_reduction_pct=100*(1-s['exact_gc_loss_ratio_vs_gc']),rmse_reduction_pct=100*(1-s['mean_rmse_ratio_vs_gc']),power_error_reduction_pct=100*(1-s['mean_power_error_ratio_vs_gc']),joint_wins=s['joint_wins_vs_gc'],eligible=s['eligible'],safety_pass=s['safety_guard_passed']))
with (D/'all_candidate_metrics.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
figures=[]; pdf=PdfPages(OUT/'v24_amse_summary_2026-10-07.pdf')
def save(fig,stem,subtitle=''):
 if subtitle: fig.text(.06,.025,subtitle,fontsize=8,color='#536172')
 fig.text(.97,.012,f'AMSE evidence review · 7 Oct 2026 · {len(figures)+1}',ha='right',fontsize=7,color='#74808c')
 pdf.savefig(fig);fig.savefig(I/(stem+'.png'),dpi=150,facecolor='white');fig.savefig(I/(stem+'.pdf'),facecolor='white');figures.append((stem,fig._suptitle.get_text() if fig._suptitle else stem));plt.close(fig)
def textpage(title,sections,stem):
 fig=plt.figure(figsize=(11.7,8.3));fig.suptitle(title,x=.06,ha='left',y=.95,fontsize=22,weight='bold'); y=.85
 for heading,body in sections:
  fig.text(.06,y,heading,fontsize=13,weight='bold',color='#12647c');y-=.036
  lines=textwrap.wrap(body,112)
  fig.text(.06,y,'\n'.join(lines),va='top',fontsize=11,linespacing=1.5);y-=.027*len(lines)+.036
 save(fig,stem)
textpage('AMSE: all available evidence',[
 ('Finding','Full AMSE improves spectral-power fidelity but sacrifices forecast accuracy. Lower AMSE weights retain more accuracy, yet no candidate in the completed joint campaign meets all three aggregate requirements plus the safety guard.'),
 ('Coverage','September 19 full-AMSE/MSE pair; September 24 lambda=0.1 blend; October 4 trajectory re-evaluation, 500-update pilot, stopped/differentiable feedback, and three objective ablations. All 49 evaluated records across the four October phases are included, with repeated controls retained separately.'),
 ('What is still pending','All six 2,000-update confirmation training runs finished. Seven evaluation tasks 15149394_0–6 and report 15149395 remain pending at the live queue check on October 7. Confirmation covers three seeds and 64 separate seasonal 2023 starts. No confirmation scores are available.'),
 ('Related MGDA experiment','MGDA combines GraphCast and spectral-power gradients. Calibration completed; both 100-update smoke runs failed bitwise resume equality of residual parameters. The 2,000-update production comparison did not launch. These are engineering results, not evidence of forecast skill.'),
 ('Reading this report','Positive reduction means better than Original GraphCast. Exact GraphCast loss is the headline metric; physical RMSE and relative spectral-power error are separate diagnostics. The companion complete PDF appends the existing 49-page field-level spectral report.')], '01_summary')
textpage('Protocols and interpretation',[
 ('Historical accuracy versus spectral diagnostics','Historical exact-loss evaluation uses 32 matched 2022 starts and 40 six-hour leads. Spectral evaluation uses eight previously inspected 2023 starts, 30–60° latitude in both hemispheres, and zonal wavenumbers 1–180. Neither is the pending year-round 2023 evaluation.'),
 ('Objective and measurements','Training AMSE interpolates spherical spectral MSE (lambda=0) and full AMSE (lambda=1), using a global T179 transform. Verification uses zonal Fourier spectra. Exact GraphCast loss retains its original normalization, latitude, pressure and variable weights; losses are pooled before the reduction ratio.'),
 ('October joint qualification','On the same eight spectral starts: exact GC loss ratio <1, mean physical-RMSE ratio <1, and mean relative-power-error ratio <1; additionally no selected primitive field/day may exceed 2% RMSE harm versus GC. RMSE/power summaries use nine fields and days 1, 3, 7, 10. Power error is averaged over spectral bins then field/day cells.'),
 ('Baseline and uncertainty limits','Historical comparisons flag numerical baseline drift and use each model’s paired GC baseline. October scores use their phase’s canonical GC reference; controls vary between re-evaluations. Do not average repeated baselines or interpret tiny differences as established gains. Development selection has no confirmatory uncertainty claim.'),
 ('Power is not accuracy','Matching power does not ensure the correct location or phase of weather features. Coherence and spectral-error decomposition in the appendix expose this distinction. No new forecast inference or training was run to prepare this report.')], '02_protocol')
# historical comparisons
fig,axes=plt.subplots(1,2,figsize=(11.7,8.3));fig.suptitle('Historical AMSE: accuracy by forecast lead',fontsize=20,y=.95)
legacy=[]
for ax,stage,title in zip(axes,['exact','spectral'],['32 starts · 2022 development','8 starts · 2023 exploratory']):
 for camp,d in old.items():
  for arm in ['mse_fp32','amse']:
   k=f'{stage}/{arm}_swa_step00500-02000'; q=d['exact_graphcast_loss'][k]
   val=100*(1-np.sum(q['full_per_step'])/np.sum(q['baseline_per_step']));assert abs(val-q['improvement_pct_rollout'])<1e-8
   label=(camp+' matched MSE') if arm=='mse_fp32' else camp
   ax.plot(np.arange(1,41)/4,q['improvement_pct_per_step'],label=f'{label}: {val:.2f}%',ls='--' if arm=='mse_fp32' else '-',lw=2)
   legacy.append({'sample':stage,'model':label,'rollout_reduction_pct':val,'day10_reduction_pct':q['improvement_pct_per_step'][-1]})
 ax.axhline(0,color='gray',lw=1);ax.set(title=title,xlabel='Forecast lead (days)',ylabel='Exact GC loss reduction (%)');ax.grid(alpha=.2);ax.legend(fontsize=8,loc='lower left')
fig.subplots_adjust(top=.85,bottom=.17,wspace=.28)
save(fig,'03_historical_accuracy','SWA 500–2000; paired baselines retained separately. Legend gives pooled rollout reduction, not mean lead percentage.')
(D/'historical_metrics.json').write_text(json.dumps(legacy,indent=2))
# all-phase tradeoffs
fig,axes=plt.subplots(2,2,figsize=(11.7,8.3));fig.suptitle('Accuracy and power: no joint winner yet',fontsize=20,y=.96)
colors=plt.get_cmap('tab10')
for ax,(phase,d) in zip(axes.ravel(),phases.items()):
 families=list(dict.fromkeys(r['family'] for r in d['records']))
 for j,fam in enumerate(families):
  rr=[r for r in d['records'] if r['family']==fam];x=[100*(1-r['score']['exact_gc_loss_ratio_vs_gc']) for r in rr]
  y=[100*(1-r['score']['mean_power_error_ratio_vs_gc']) for r in rr]
  ax.plot(x,y,'o-',ms=4,lw=.8,color=colors(j),label=fam.replace('_',' '))
 ax.axhline(0,color='gray',lw=.8);ax.axvline(0,color='gray',lw=.8);ax.grid(alpha=.2);ax.set_title(phase.title());ax.set_xlabel('Exact GC loss reduction (%)');ax.set_ylabel('Power-error reduction (%)');ax.legend(fontsize=6.5,loc='best')
fig.subplots_adjust(top=.87,bottom=.12,hspace=.45,wspace=.32)
save(fig,'04_joint_tradeoffs','Same eight 2023 starts. Upper right improves both axes; qualification additionally requires physical RMSE and safety.')
# pilot trajectories
fig,axes=plt.subplots(1,3,figsize=(11.7,8.3));fig.suptitle('500-update pilot: increasing AMSE trades accuracy for power',fontsize=18,y=.95)
for ax,(key,label) in zip(axes,[('gc_reduction_pct','Exact GC loss reduction (%)'),('rmse_reduction_pct','Mean physical RMSE reduction (%)'),('power_error_reduction_pct','Power-error reduction (%)')]):
 pr=[r for r in rows if r['phase']=='pilot'];init=next(r for r in pr if r['id']=='mature_mse')
 for fam in ['mse','spectral_mse','amse_l025','amse_l050']:
  rr=[r for r in pr if r['family']==fam];ax.plot([0]+[r['step'] for r in rr],[init[key]]+[r[key] for r in rr],'o-',label=fam.replace('_',' '),ms=4)
 ax.set(xlabel='Continuation updates',ylabel=label);ax.axhline(0,color='gray',lw=.8);ax.grid(alpha=.2)
axes[0].legend(fontsize=8);fig.subplots_adjust(top=.85,bottom=.17,wspace=.35)
save(fig,'05_pilot_trajectories','Common mature-MSE start; four matched 500-update continuations. All checkpoints shown; all fail joint qualification.')
# feedback & adaptive bars
for phase,stem in [('feedback','06_feedback'),('adaptive','07_objective_ablations')]:
 rr=[r for r in rows if r['phase']==phase];fig,axes=plt.subplots(1,3,figsize=(11.7,8.3),sharey=True);fig.suptitle(phase.title()+' experiments: completed development results',fontsize=19,y=.95)
 labels=[r['id'].replace('_step',' @').replace('adaptive_','').replace('feedback_','') for r in rr]
 for ax,key,title in zip(axes,['gc_reduction_pct','rmse_reduction_pct','power_error_reduction_pct'],['Exact GC loss','Mean physical RMSE','Relative power error']):
  vv=[r[key] for r in rr];ax.barh(range(len(rr)),vv,color=['#63717d']+['#1a8090']*(len(rr)-1));ax.axvline(0,color='gray',lw=.8);ax.set_title(title);ax.set_xlabel('Reduction vs GC (%)');ax.grid(axis='x',alpha=.2);ax.set_xlim(min(0,min(vv))-max(abs(np.array(vv)).max()*.23,.5),max(0,max(vv))+max(abs(np.array(vv)).max()*.23,.5))
  for i,v in enumerate(vv):ax.text(v,i,f' {v:.2f}',va='center',ha='left' if v>=0 else 'right',fontsize=8)
 axes[0].set_yticks(range(len(rr)),labels,fontsize=8);axes[0].invert_yaxis();fig.subplots_adjust(left=.24,right=.96,top=.85,bottom=.14,wspace=.32)
 save(fig,stem,'Exploratory eight-start 2023 diagnostics. Positive is better. No candidate passes the joint qualification gate.')
# feature heatmap for locked candidate
r=next(r for r in phases['adaptive']['records'] if r['id']=='adaptive_precip_step00100');cells=r['score']['per_feature_lead'];features=list(dict.fromkeys(x['feature'] for x in cells));days=[1,3,7,10]
fig,axes=plt.subplots(1,3,figsize=(11.7,8.3));fig.suptitle('Locked recipe: where does it help or hurt?',fontsize=20,y=.95)
for ax,key,title,conv in zip(axes,['rmse_ratio_vs_mse','power_error_ratio_vs_mse','coherence_change_vs_mse'],['Physical RMSE reduction','Power-error reduction','Coherence change (pp)'],[lambda v:100*(1-v),lambda v:100*(1-v),lambda v:100*v]):
 arr=np.array([[conv(next(x[key] for x in cells if x['feature']==f and x['day']==d)) for d in days] for f in features]); lim=max(abs(arr).max(),.01)
 im=ax.imshow(arr,cmap='RdBu',vmin=-lim,vmax=lim,aspect='auto');ax.set_xticks(range(4),['D1','D3','D7','D10']);ax.set_yticks(range(9),features);ax.set_title(title,fontsize=11)
 for i in range(9):
  for j in range(4):ax.text(j,i,f'{arr[i,j]:.1f}',ha='center',va='center',fontsize=8,color='white' if abs(arr[i,j])>.6*lim else 'black')
 fig.colorbar(im,ax=ax,orientation='horizontal',pad=.08,shrink=.9)
fig.subplots_adjust(top=.83,bottom=.18,wspace=.36)
save(fig,'08_locked_recipe_fields','adaptive_precip @100 versus phase MSE control. Positive is better; blue helps, red harms. This is development, not confirmation.')
# full inventory readable tables
for phase in phases:
 rr=[r for r in rows if r['phase']==phase]
 fig,ax=plt.subplots(figsize=(11.7,8.3));ax.axis('off');fig.suptitle('Complete checkpoint inventory: '+phase,fontsize=20,y=.96)
 vals=[[r['id'],f"{r['gc_reduction_pct']:.2f}",f"{r['rmse_reduction_pct']:.2f}",f"{r['power_error_reduction_pct']:.2f}",f"{r['joint_wins']}/36",'pass' if r['safety_pass'] else 'FAIL','yes' if r['eligible'] else 'no'] for r in rr]
 tab=ax.table(cellText=vals,colLabels=['Candidate','GC loss %','RMSE %','Power error %','Joint cells','Safety','Eligible'],colWidths=[.39,.10,.10,.12,.10,.09,.08],loc='upper center',cellLoc='left');tab.auto_set_font_size(False);tab.set_fontsize(8);tab.scale(1,1.45)
 for (i,j),cell in tab.get_celld().items():
  cell.set_edgecolor('#dce3e8');cell.set_facecolor('#e7eff4' if i==0 else '#f6f8fa' if i%2==0 else 'white')
 fig.subplots_adjust(left=.04,right=.96,top=.87,bottom=.15)
 save(fig,'inventory_'+phase,'All percentage columns are reductions versus GC; positive is better. Joint cells improve both physical RMSE and power error.')
textpage('Pending work and what the evidence supports',[
 ('Confirmation: training complete, evaluation pending','Six final step2000 checkpoints exist: MSE and locked AMSE recipe at seeds 22, 23 and 24. Evaluation uses 64 seasonal 2023 starts and averages separate-model metrics, never forecast fields. The recipe is lambda=0.25 with precipitation lambda=0; it was not qualified on development. Selection is locked before confirmation.'),
 ('MGDA: blocked at engineering validation','Calibration job 15069232 completed. Smoke jobs 15069233_0 and _1 reached 100 updates but failed uninterrupted-versus-resumed bitwise residual-parameter equality. A failure shared by MGDA and MSE does not demonstrate failure of the scientific objective. No production forecast comparison is available.'),
 ('2023 scope','The eight-case spectral diagnostics have completed and were inspected during development. The separate 122-start year-round memory/accuracy campaign remains pending numerical qualification; the earlier daily campaign failed baseline agreement. The 64-start AMSE confirmation is a third, separate evaluation.'),
 ('Supported conclusion','Full AMSE produces materially better power fidelity with worse exact forecast loss. Weak AMSE produces an intermediate trade-off. The 500-update continuations, feedback tests and adaptive variants have not established a joint improvement. Small differences are particularly sensitive to observed numerical drift.'),
 ('Recommended next evidence','Finish the already queued confirmation evaluations and inspect all fields, all seeds and paired intervals. Repair and qualify resume/numerical behavior before running MGDA production or releasing year-round evaluation. Preserve negative outcomes and keep selection fixed.')], '13_pending_and_conclusions')
pdf.close()
# complete report includes all prior field diagnostics
full=OUT/'v24_amse_complete_2026-10-07.pdf'
subprocess.run(['gs','-q','-dBATCH','-dNOPAUSE','-sDEVICE=pdfwrite',f'-sOutputFile={full}',str(OUT/'v24_amse_summary_2026-10-07.pdf'),str(OUT/'v24_amse_features_2026-10-04.pdf')],check=True)
# self-contained relative gallery and provenance
html=['<!doctype html><html><meta charset="utf-8"><title>AMSE report · 7 October 2026</title><style>body{font:17px system-ui;max-width:1100px;margin:40px auto;background:#f7f9fb;color:#172b3a}img{width:100%;background:white}article{margin:40px 0}a{color:#12647c}</style><h1>AMSE evidence review · 7 October 2026</h1><p>Completed development results; confirmation evaluation is pending. Positive reductions mean better than Original GraphCast.</p>']
for stem,title in figures:html.append(f'<article><h2>{title}</h2><a href="{stem}.pdf">Vector PDF</a><img src="{stem}.png" alt="{title}"></article>')
html.append('</html>');(I/'index.html').write_text('\n'.join(html))
manifest={'created':datetime.now(ZoneInfo('America/New_York')).isoformat(),'sources':sources,'records':len(rows),'pages':len(figures),'confirmation_status':'6 training tasks complete; 7 evaluation tasks and report pending','outputs':[str(OUT/'v24_amse_summary_2026-10-07.pdf'),str(full)],'figures':figures}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2))
shutil.copy('/tmp/build_amse_report.py',D/'build_report.py')
with zipfile.ZipFile(OUT/'v24_amse_plots_2026-10-07.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in I.iterdir():z.write(p,'summary/'+p.name)
 for p in (R/'plots/analyze_models/images/resolution_eval/v24_amse_feature_report_20261004').glob('*'):
  if p.suffix in ['.pdf','.png'] and not p.name.startswith('report_'):z.write(p,'historical_field_diagnostics/'+p.name)
 for p in D.iterdir():z.write(p,'data/'+p.name)
print(json.dumps({'pages':len(figures),'records':len(rows),'legacy':legacy,'files':manifest['outputs']},indent=2))
